package com.example.mathiq

import android.content.DialogInterface
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AlertDialog

class HomeActivity : AppCompatActivity() {

    private lateinit var gameButton: Button
    private lateinit var scoreButton: Button
    private lateinit var exitButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)

        gameButton = findViewById(R.id.gameButton)
        scoreButton = findViewById(R.id.scoreButton)
        exitButton = findViewById(R.id.exitButton)

        gameButton.setOnClickListener {
            startMainActivity()
        }

        scoreButton.setOnClickListener {
            startHighScoresActivity()
        }

        exitButton.setOnClickListener {
            onBackPressed()
        }
    }

    private fun startMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun startHighScoresActivity() {
        val intent = Intent(this, HighScoresActivity::class.java)
        startActivity(intent)
        finish()
    }

    override fun onBackPressed() {
        showExitConfirmationDialog()
    }

    private fun showExitConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Exit")
            .setMessage("Are you sure you want to exit the app?")
            .setPositiveButton("Exit") { dialog, which ->
                finishAffinity()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

